package TheChallenge;

import java.util.List;

/**
 * Created by wentingruan on 2017/10/26.
 */
public class Workflow {
    public List<List<String>> getWorkflow(List<List<String>> input) {

    }

    public static void main(String[] args) {

    }
}
